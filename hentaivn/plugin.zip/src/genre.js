function execute() {
    return Response.success([
        {
            "input": "/the-loai/3d-hentai/",
            "title": "3D Hentai",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/action/",
            "title": "Action",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/adult/",
            "title": "Adult",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/ahegao/",
            "title": "Ahegao",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/anal/",
            "title": "Anal",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/animal/",
            "title": "Animal",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/artist-cg/",
            "title": "Artist CG",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/bao-dam/",
            "title": "Bạo Dâm",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/bdsm/",
            "title": "BDSM",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/body-swap/",
            "title": "Body Swap",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/big-ass/",
            "title": "Big Ass",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/big-boobs/",
            "title": "Big Boobs",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/big-penis/",
            "title": "Big Penis",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/blowjobs/",
            "title": "BlowJobs",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/bondage/",
            "title": "Bondage",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/bodysuit/",
            "title": "Bodysuit",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/breastjobs/",
            "title": "BreastJobs",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/breast-sucking/",
            "title": "Breast Sucking",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/cosplay/",
            "title": "Cosplay",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/dark-skin/",
            "title": "Dark Skin",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/demon/",
            "title": "Demon",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/dirty-old-man/",
            "title": "Dirty Old Man",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/doujinshi/",
            "title": "Doujinshi",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/ecchi/",
            "title": "Ecchi",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/elf/",
            "title": "Elf",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/exhibitionism/",
            "title": "Exhibitionism",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/femdom/",
            "title": "Femdom",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/full-color/",
            "title": "Full Color",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/furry/",
            "title": "Furry",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/futanari/",
            "title": "Futanari",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/footjob/",
            "title": "Footjob",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/game/",
            "title": "Game",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/gender-bender/",
            "title": "Gender Bender",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/gothic-lolita/",
            "title": "Gothic Lolita",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/guro/",
            "title": "Guro",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/harem/",
            "title": "Harem",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/hentaivn/",
            "title": "HentaiVN",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/housewife/",
            "title": "Housewife",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/horror/",
            "title": "Horror",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/insect-con-trung/",
            "title": "Insect (Côn Trùng)",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/loli/",
            "title": "Loli",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/loan-luan/",
            "title": "Loạn Luân",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/maids/",
            "title": "Maids",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/manhwa/",
            "title": "Manhwa",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/masturbation/",
            "title": "Masturbation",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/milf/",
            "title": "Milf",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/mind-control/",
            "title": "Mind Control",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/monster/",
            "title": "Monster",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/mother/",
            "title": "Mother",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/nurse/",
            "title": "Nurse",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/ntr/",
            "title": "NTR",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/old-man/",
            "title": "Old Man",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/oneshot/",
            "title": "Oneshot",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/pantyhose/",
            "title": "Pantyhose",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/pregnant/",
            "title": "Pregnant",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/rape/",
            "title": "Rape",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/scat/",
            "title": "Scat",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/school-uniform/",
            "title": "School Uniform",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/sex-toys/",
            "title": "Sex Toys",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/sister/",
            "title": "Sister",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/shota/",
            "title": "Shota",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/slave/",
            "title": "Slave",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/sleeping/",
            "title": "Sleeping",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/sports/",
            "title": "Sports",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/teacher/",
            "title": "Teacher",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/tentacles/",
            "title": "Tentacles",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/tomboy/",
            "title": "Tomboy",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/trap/",
            "title": "Trap",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/vampire/",
            "title": "Vampire",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/x-ray/",
            "title": "X-ray",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/yandere/",
            "title": "Yandere",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/yaoi/",
            "title": "Yaoi",
            "script": "gen.js"
        }
    ]);
}